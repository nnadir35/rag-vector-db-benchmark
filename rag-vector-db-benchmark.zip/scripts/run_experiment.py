#!/usr/bin/env python3
"""Run a RAG benchmark experiment from a configuration file.

This script acts as the main CLI entry point. It orchestrates reading YAML,
initializing pipeline components, running inference against standard
evaluation datasets, saving results logically, and displaying them.
"""

import argparse
import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime

# Add project root to PYTHONPATH
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

from src.chunkers.fixed_size_chunker import FixedSizeChunker
from src.datasets import (
    DatasetLoader,
    MSMARCODatasetConfig,
    MSMARCOLoader,
    SQuADDatasetConfig,
    SQuADLoader,
)
from src.embedders.sentence_transformers_embedder import SentenceTransformersEmbedder
from src.evaluators.answer_quality_evaluator import AnswerQualityEvaluator
from src.evaluators.generation_evaluator import GenerationEvaluator
from src.evaluators.retrieval_evaluator import RetrievalEvaluator
from src.generators.universal_generator import UniversalGenerator
from src.pipeline.rag_pipeline import RAGPipeline
from src.retrievers.factory import build_retriever_from_yaml
from src.utils.config_loader import build_component_configs, load_yaml

# Configure simple logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


def tabulate_results(all_metrics: list[dict[str, float] | None], total_time: float) -> None:
    """Print terminal-friendly metrics summary table."""
    valid_metrics = [m for m in all_metrics if m is not None]

    print("\n" + "="*50)
    print("EXPERIMENT RESULTS SUMMARY")
    print("="*50)
    print(f"Total Queries Evaluated : {len(all_metrics)}")
    print(f"Successful Evaluations  : {len(valid_metrics)}")
    print(f"Total Pipeline Latency  : {total_time:.4f} seconds")

    if not valid_metrics:
        print("No evaluation metrics were generated.")
        return

    # Aggregate metrics
    keys = valid_metrics[0].keys()
    agg = {key: sum(m[key] for m in valid_metrics) / len(valid_metrics) for key in keys}

    print("-" * 50)
    print(f"{'Metric':<20} | {'Average Score':<15}")
    print("-" * 50)

    for key in sorted(keys):
        print(f"{key:<20} | {agg[key]:.4f}")
    print("=" * 50 + "\n")


def _compute_summary(metrics_list: list) -> dict:
    """Per-query metrik listesinden ortalama hesaplar."""
    valid = [m for m in metrics_list if m is not None]
    if not valid:
        return {}
    keys = valid[0].keys()
    return {
        key: round(sum(m[key] for m in valid) / len(valid), 4)
        for key in keys
    }


async def main_async(args: argparse.Namespace) -> None:
    # 1. Load configuration
    try:
        raw_config = load_yaml(args.config)
        exp_config = build_component_configs(raw_config)
        logging.info(f"Loaded configuration for experiment: {exp_config.name}")
    except Exception as e:
        logging.error(f"Failed to load config: {e}")
        return

    # 2. Setup Data Loader
    logging.info("Loading dataset...")
    if isinstance(exp_config.dataset, MSMARCODatasetConfig):
        loader: DatasetLoader = MSMARCOLoader(exp_config.dataset)
    elif isinstance(exp_config.dataset, SQuADDatasetConfig):
        loader = SQuADLoader(exp_config.dataset)
    else:  # pragma: no cover - type narrowing guard
        raise TypeError(f"Unsupported dataset config: {type(exp_config.dataset)!r}")
    try:
        queries, ground_truth = loader.load()
        gold_answers = loader.load_gold_answers()
        raw_documents = loader.load_documents()
        logging.info(f"Loaded {len(queries)} queries and {len(raw_documents)} documents.")
    except Exception as e:
        logging.error(f"Failed to load dataset: {e}")
        return

    # Convert documents to Chunks using FixedSizeChunker
    logging.info("Chunking documents...")
    chunker = FixedSizeChunker(exp_config.chunker)
    chunks = []
    for doc in raw_documents:
        chunks.extend(chunker.chunk(doc))
    logging.info(f"Generated {len(chunks)} chunks from {len(raw_documents)} documents.")

    # 3. Component Instantiation
    logging.info("Initializing Generator and Evaluators...")
    generator = UniversalGenerator(exp_config.generator)
    evaluator = RetrievalEvaluator(exp_config.evaluator)

    judge_config = exp_config.judge_generator or exp_config.generator
    judge_gen = UniversalGenerator(judge_config) if exp_config.judge_generator else generator
    generation_evaluator = GenerationEvaluator(judge_generator=judge_gen)

    answer_quality_evaluator = AnswerQualityEvaluator()

    logging.info("Initializing Embedder and computing embeddings...")
    embedder = SentenceTransformersEmbedder(exp_config.embedder)
    embeddings = embedder.embed_chunks(chunks)

    logging.info("Initializing retriever and indexing chunks...")
    retriever = build_retriever_from_yaml(raw_config, embedder)

    # Clear the collection to ensure a fresh index for each run
    retriever.clear()
    retriever.add_chunks(chunks, embeddings)

    # Pipeline Setup
    pipeline = RAGPipeline(
        retriever=retriever,
        generator=generator,
        config=exp_config.pipeline,
        retrieval_evaluator=evaluator,
        generation_evaluator=generation_evaluator,
        answer_quality_evaluator=answer_quality_evaluator
    )

    # 4. Run Experiment
    logging.info("Executing pipeline on queries (this may take a while)...")

    start_time = time.time()
    query_texts = [q.text for q in queries]
    # Keep ground truth matching based on original query ids
    gt_lists = [list(ground_truth.get(q.id, set())) for q in queries]
    gold_answer_lists = [gold_answers.get(q.id, []) for q in queries]

    # Handle batch processing safely by chunking locally so we don't bombard APIs simultaneously
    batch_size = 5
    all_results = []

    for i in range(0, len(query_texts), batch_size):
        batch_q = query_texts[i:i+batch_size]
        batch_gt = gt_lists[i:i+batch_size]
        batch_gold_answers = gold_answer_lists[i:i+batch_size]
        logging.info(f"Processing batch {i//batch_size + 1}...")
        results = await pipeline.run_batch(batch_q, batch_gt, batch_gold_answers)
        all_results.extend(results)

    execution_time = time.time() - start_time

    # 5. Summarize and Print Table
    extracted_metrics = [r.retrieval_metrics for r in all_results]
    tabulate_results(extracted_metrics, execution_time)

    # 6. Save JSON Data
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    os.makedirs("experiments/results", exist_ok=True)
    out_file = f"experiments/results/{ts}_{exp_config.name}.json"

    output_data = {
        "experiment_name": exp_config.name,
        "timestamp": ts,
        "raw_config": raw_config,
        "metrics_summary": _compute_summary(extracted_metrics),
        "results": [
            {
                "query": r.query.text,
                "response": r.rag_response.response,
                "latency": r.total_latency_seconds,
                "metrics": r.retrieval_metrics
            }
            for r in all_results
        ]
    }

    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    logging.info(f"Full details saved to {out_file}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run RAG Pipeline Experiment")
    parser.add_argument("--config", type=str, required=True, help="Path to YAML configuration file")
    args = parser.parse_args()

    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
